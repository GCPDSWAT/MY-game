package app.ok200.android.debug

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import app.ok200.android.Ok200Application
import app.ok200.android.network.NetworkAddressResolver
import app.ok200.android.server.ServerPhase
import app.ok200.android.settings.ServerLifetimeMode
import app.ok200.android.settings.WakeLockMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

private const val TAG = "DebugRpcProvider"

class DebugRpcProvider : ContentProvider() {

    private val app: Ok200Application
        get() = context!!.applicationContext as Ok200Application

    private val settings
        get() = app.settingsStore

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        Log.i(TAG, "RPC call: method=$method arg=$arg")
        val result = try {
            when (method) {
                "ping" -> handlePing()
                "getState" -> handleGetState()
                "getNetworkAddresses" -> handleGetNetworkAddresses()
                "setPort" -> handleSetPort(arg)
                "setRootPath" -> handleSetRootPath(arg)
                "setRootUri" -> handleSetRootUri(arg)
                "releaseRootPermission" -> handleReleaseRootPermission()
                "startServer" -> handleStartServer()
                "stopServer" -> handleStopServer()
                "getPowerState" -> handleGetPowerState()
                "getSettings" -> handleGetSettings()
                "setWakeLockMode" -> handleSetWakeLockMode(arg)
                "setLifetimeMode" -> handleSetLifetimeMode(arg)
                "setBackgroundEnabled" -> handleSetBackgroundEnabled(arg)
                "setLanEnabled" -> handleBooleanSetting(arg, "lanEnabled") { settings.lanEnabled = it }
                "setDirectoryListing" -> handleBooleanSetting(arg, "directoryListing") { settings.directoryListing = it }
                "setCorsEnabled" -> handleBooleanSetting(arg, "corsEnabled") { settings.corsEnabled = it }
                "setSpaEnabled" -> handleBooleanSetting(arg, "spaEnabled") { settings.spaEnabled = it }
                "setStartOnBoot" -> handleSetStartOnBoot(arg)
                "setShutdownOnLowBattery" -> handleBooleanSetting(arg, "shutdownOnLowBattery") {
                    settings.shutdownOnLowBattery = it
                    app.serverController.onPowerSettingsChanged()
                }
                "setShutdownBatteryThreshold" -> handleBatteryThreshold(arg)
                else -> errorJson("Unknown method: $method")
            }
        } catch (e: Exception) {
            Log.e(TAG, "RPC error", e)
            errorJson(e.message ?: "Unknown error")
        }
        return Bundle().apply { putString("result", result) }
    }

    private fun handlePing(): String {
        return """{"ok":true}"""
    }

    private fun handleGetState(): String {
        val state = app.serverController.state.value

        return buildJsonObject {
            put("running", state.running)
            put("phase", state.phase.name.lowercase())
            put("port", if (state.port > 0) state.port else settings.port)
            put("host", state.host)
            put("error", state.error?.let { JsonPrimitive(it) } ?: JsonNull)
            put("rootUri", settings.rootUri?.let { JsonPrimitive(it) } ?: JsonNull)
            put("rootDisplayName", settings.rootDisplayName?.let { JsonPrimitive(it) } ?: JsonNull)
            put("configuredPort", settings.port)
            put("controllerInitialized", true)
        }.toString()
    }

    private fun handleGetNetworkAddresses(): String {
        val resolver = NetworkAddressResolver(context!!)
        val state = app.serverController.state.value
        val port = state.port.takeIf { it > 0 } ?: settings.port
        return buildJsonObject {
            put("ok", true)
            put("isChromeOs", resolver.isChromeOs)
            put("chromeOsIpv4Instructions", resolver.isChromeOs && settings.lanEnabled)
            put(
                "addresses",
                buildJsonArray {
                    resolver.currentAddresses().forEach { address ->
                        add(
                            buildJsonObject {
                                put("interface", address.interfaceName ?: "")
                                put("address", address.address)
                                put("prefixLength", address.prefixLength)
                                put("family", address.family.name.lowercase())
                                put("scope", address.scope.name.lowercase())
                                put("availability", address.availability.name.lowercase())
                                put("usableFromAnotherDevice", address.usableFromAnotherDevice)
                                if (address.usableFromAnotherDevice) {
                                    put("url", address.httpUrl(port))
                                }
                            }
                        )
                    }
                }
            )
        }.toString()
    }

    private fun handleSetPort(arg: String?): String {
        val port = arg?.toIntOrNull()
            ?: return errorJson("Invalid port: $arg")
        if (port !in 0..65535)
            return errorJson("Port out of range: $port")
        settings.port = port
        return """{"ok":true,"port":$port}"""
    }

    private fun handleSetRootPath(arg: String?): String {
        if (arg.isNullOrBlank())
            return errorJson("Path required")
        val uri = Uri.parse("file://$arg")
        val displayName = arg.substringAfterLast('/')
        settings.rootUri = uri.toString()
        settings.rootDisplayName = displayName
        return buildJsonObject {
            put("ok", true)
            put("rootUri", uri.toString())
            put("rootDisplayName", displayName)
        }.toString()
    }

    private fun handleSetRootUri(arg: String?): String {
        if (arg.isNullOrBlank()) return errorJson("URI required")
        val uri = Uri.parse(arg)
        if (uri.scheme != "content" && uri.scheme != "file") {
            return errorJson("Only content and file URIs are supported")
        }
        val displayName = Uri.decode(uri.lastPathSegment ?: arg)
        settings.rootUri = uri.toString()
        settings.rootDisplayName = displayName
        return buildJsonObject {
            put("ok", true)
            put("rootUri", uri.toString())
            put("rootDisplayName", displayName)
            put("persistedReadPermission", hasPersistedReadPermission(uri))
        }.toString()
    }

    private fun handleReleaseRootPermission(): String {
        val uri = settings.rootUri?.let(Uri::parse)
            ?: return errorJson("No root URI configured")
        if (uri.scheme != "content") return errorJson("Configured root is not a content URI")
        val persisted = context!!.contentResolver.persistedUriPermissions
            .firstOrNull { it.uri == uri && it.isReadPermission }
            ?: return errorJson("No persisted read permission for configured root")
        context!!.contentResolver.releasePersistableUriPermission(
            persisted.uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        return """{"ok":true,"persistedReadPermission":false}"""
    }

    private fun handleStartServer(): String {
        val rootUri = settings.rootUri
            ?: return errorJson("No root URI configured. Call setRootPath first.")

        Uri.parse(rootUri)
        val controller = app.serverController
        controller.requestStart()

        val finalState = runBlocking {
            withTimeoutOrNull(5_000L) {
                controller.state.first { it.running || it.phase == ServerPhase.FAILED }
            }
        } ?: controller.state.value

        return buildJsonObject {
            put("ok", finalState.running)
            put("running", finalState.running)
            put("port", finalState.port)
            put("host", finalState.host)
            if (finalState.error != null) put("error", finalState.error)
        }.toString()
    }

    private fun handleStopServer(): String {
        val controller = app.serverController
        controller.requestStop()
        val finalState = runBlocking {
            withTimeoutOrNull(5_000L) {
                controller.state.first { it.phase == ServerPhase.STOPPED }
            }
        } ?: controller.state.value
        return buildJsonObject {
            put("ok", !finalState.running)
            put("running", finalState.running)
            put("phase", finalState.phase.name.lowercase())
        }.toString()
    }

    private fun handleGetPowerState(): String {
        return buildJsonObject {
            put("ok", true)
            put("summary", app.dozeMonitor.getDebugSummary())
            put("powerState", app.dozeMonitor.powerState.value.name)
            put("isCharging", app.dozeMonitor.isCharging.value)
            put("isDozing", app.dozeMonitor.isDozing.value)
            put("isScreenOn", app.dozeMonitor.isScreenOn.value)
            put("batteryLevel", app.dozeMonitor.batteryLevel.value)
            put("isPowerSave", app.dozeMonitor.isPowerSave.value)
            put("ignoringBatteryOptimizations", app.dozeMonitor.isIgnoringBatteryOptimizations())
        }.toString()
    }

    private fun handleGetSettings(): String {
        val rootUri = settings.rootUri?.let(Uri::parse)
        return buildJsonObject {
            put("ok", true)
            put("port", settings.port)
            put("rootUri", settings.rootUri?.let { JsonPrimitive(it) } ?: JsonNull)
            put("rootDisplayName", settings.rootDisplayName?.let { JsonPrimitive(it) } ?: JsonNull)
            put(
                "allFilesAccess",
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    Environment.isExternalStorageManager()
                } else {
                    true
                }
            )
            put(
                "persistedRootReadPermission",
                rootUri?.takeIf { it.scheme == "content" }?.let(::hasPersistedReadPermission)
                    ?: false
            )
            put("lanEnabled", settings.lanEnabled)
            put("directoryListing", settings.directoryListing)
            put("corsEnabled", settings.corsEnabled)
            put("spaEnabled", settings.spaEnabled)
            put("lifetimeMode", settings.lifetimeMode.key)
            put("backgroundEnabled", settings.lifetimeMode != ServerLifetimeMode.APP_OPEN)
            put("wakeLockMode", settings.wakeLockMode.key)
            put("startOnBoot", settings.startOnBoot)
            put("shutdownOnLowBattery", settings.shutdownOnLowBattery)
            put("shutdownBatteryThreshold", settings.shutdownBatteryThreshold)
        }.toString()
    }

    private fun hasPersistedReadPermission(uri: Uri): Boolean =
        context!!.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission
        }

    private fun handleSetWakeLockMode(arg: String?): String {
        if (arg.isNullOrBlank())
            return errorJson("Mode required (none, wifi_only, full)")
        val mode = WakeLockMode.fromString(arg)
        if (!app.serverController.updateWakeLockMode(mode)) {
            return errorJson("Wake locks require Reliable background with notifications enabled")
        }
        return buildJsonObject {
            put("ok", true)
            put("wakeLockMode", mode.key)
        }.toString()
    }

    private fun handleSetLifetimeMode(arg: String?): String {
        val mode = ServerLifetimeMode.entries.firstOrNull { it.key == arg?.lowercase() }
            ?: return errorJson("Mode required (app_open, background, reliable)")
        if (!app.serverController.onLifetimeModeChanged(mode)) {
            return errorJson("Reliable background requires notifications")
        }
        return buildJsonObject {
            put("ok", true)
            put("lifetimeMode", settings.lifetimeMode.key)
        }.toString()
    }

    private fun handleSetBackgroundEnabled(arg: String?): String {
        val enabled = when (arg?.lowercase()) {
            "true", "1", "yes" -> true
            "false", "0", "no" -> false
            else -> return errorJson("Boolean required: $arg")
        }
        val mode = if (enabled) ServerLifetimeMode.RELIABLE else ServerLifetimeMode.APP_OPEN
        if (!app.serverController.onLifetimeModeChanged(mode)) {
            return errorJson("Reliable background requires notifications")
        }
        return buildJsonObject {
            put("ok", true)
            put("backgroundEnabled", enabled)
            put("lifetimeMode", mode.key)
        }.toString()
    }

    private fun handleSetStartOnBoot(arg: String?): String {
        val enabled = parseBoolean(arg) ?: return errorJson("Boolean required: $arg")
        if (!app.serverController.setStartOnBoot(enabled)) {
            return errorJson("Start on boot requires Reliable background with notifications enabled")
        }
        return buildJsonObject {
            put("ok", true)
            put("startOnBoot", settings.startOnBoot)
        }.toString()
    }

    private fun handleBooleanSetting(
        arg: String?,
        name: String,
        update: (Boolean) -> Unit
    ): String {
        val enabled = parseBoolean(arg) ?: return errorJson("Boolean required: $arg")
        update(enabled)
        return buildJsonObject {
            put("ok", true)
            put(name, enabled)
        }.toString()
    }

    private fun handleBatteryThreshold(arg: String?): String {
        val threshold = arg?.toIntOrNull()?.takeIf { it in 5..50 }
            ?: return errorJson("Threshold must be 5..50")
        settings.shutdownBatteryThreshold = threshold
        app.serverController.onPowerSettingsChanged()
        return """{"ok":true,"shutdownBatteryThreshold":$threshold}"""
    }

    private fun parseBoolean(value: String?): Boolean? = when (value?.lowercase()) {
        "true", "1", "yes" -> true
        "false", "0", "no" -> false
        else -> null
    }

    private fun errorJson(message: String): String {
        return buildJsonObject {
            put("ok", false)
            put("error", message)
        }.toString()
    }

    override fun onCreate(): Boolean = true
    override fun query(u: Uri, p: Array<String>?, s: String?, a: Array<String>?, o: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<String>?): Int = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<String>?): Int = 0
}
