# Desktop Runtime

> The desktop product keeps Tauri and its webview for control/configuration,
> but the HTTP server moves out of JavaScript and into a small Rust core shared
> by the Windows, macOS, and Linux builds.

Topic: desktop-native-core

Status: **Rust-native desktop `v0.1.6` is published with complete signed
macOS arm64/x64, Windows x64, and Linux arm64/x64 artifacts. Exact
post-publication macOS arm64 app, Windows NSIS, and Linux arm64 AppImage smoke
passes artifact identity, server, persistence, updater, autostart, tray-state,
native-host, and cleanup checks. It also exposes two hard-rule defects: the
main-window settings dialog is clipped or scrolls out of view on Windows and
Linux, and disabling Run in Background does not exit when the last window is
closed. On Windows, combining that behavior with a hidden tray can leave an
unrecoverable invisible instance and subsequent stuck processes. The signed
distribution remains valid, but `v0.1.6` is not accepted as a promotion-ready
settings/recovery release. Exact prior-public update and production-extension
acceptance remains recorded against `v0.1.5`. A native ARM64 Linux Chrome test
now proves `v0.1.6` store delivery and cold extension launch, but every repeated
launch leaves another defunct desktop child under the connected native host.**

Last reconciled: **2026-08-04**.

Implementation sequencing lives in
[Tactical 000](../tactical/000-desktop-native-core-and-release-readiness.md);
the standalone core boundary and compatibility baseline are recorded in
[Tactical 002](../tactical/002-standalone-rust-http-core.md), and the desktop
cutover is recorded in
[Tactical 003](../tactical/003-native-desktop-control-surface.md). The compact
portrait review surface and browser-like Rust directory listing are recorded
in
[Tactical 004](../tactical/004-portrait-desktop-polish-and-directory-listing.md).
The in-app updater behavior and its signed public-artifact proof are recorded
in [Tactical 005](../tactical/005-in-app-desktop-updater.md).
Published Linux package smoke and the AppImage launcher defect are recorded in
[Tactical 007](../tactical/007-linux-desktop-validation.md).
The accepted AppImage-first repair and distribution path are recorded in
[Tactical 008](../tactical/008-appimage-first-linux-distribution.md).
The final release-confidence gates and manual sign-off boundary are recorded
in [Tactical 009](../tactical/009-release-confidence-closeout.md).
The active settings/lifecycle repair and exact public three-OS acceptance are
owned by [Tactical 015](../tactical/015-desktop-production-validation.md) and
the [desktop production validation runbook](../runbooks/desktop-production-validation.md).
Retirement of the unpublished Node CLI and stranded TypeScript engine is
recorded in [Tactical 013](../tactical/013-retire-typescript-cli.md).
Future UPnP/public-listening work is owned by
[`internet-exposure-and-port-mapping.md`](internet-exposure-and-port-mapping.md).
Current product naming is governed by
[`product-branding.md`](product-branding.md).

## Scope

This topic owns:

- the current and target desktop runtime boundary;
- ownership of desktop HTTP behavior, configuration, and lifecycle;
- what remains in the Tauri webview;
- compatibility during the desktop migration; and
- the relationship between desktop, Android, ChromeOS Linux, and the extension.

It does not require one runtime implementation across every product. In
particular, it does not reopen the Transistor/embedded-JavaScript architecture
experiment. Android has separately adopted a Kotlin core under
[`android-runtime.md`](android-runtime.md); the unpublished Node/TypeScript
implementation has been retired.

## Product decision

The project is a replacement for the legacy Chrome packaged app, not a vehicle
for proving a cross-platform JavaScript socket/filesystem architecture.

The desktop target is:

```text
Tauri webview
  React controls: roots, port, options, start/stop, status, logs
       |
       | narrow typed Tauri commands and events
       v
Rust desktop application state
       |
       +-- ok200-core: HTTP parsing/serving, lifecycle, config validation
       +-- native filesystem and networking
       +-- persistence and request-log event production
```

The webview is a management surface. It must not accept sockets, parse HTTP,
stream file bytes, or keep the server alive. Closing or reloading the webview
must not accidentally stop a server that is configured to remain in the
background.

### Main-window settings rule

The desktop main window is the canonical, always-available control surface.
Every persistent app option and every action needed to manage or exit the app
must be reachable there. Native application menus and tray/status-icon menus
may mirror those controls as convenient shortcuts, but they must never be the
only route to a setting or action. Product behavior and recoverability must not
depend on a tray implementation being visible or supported by the desktop
environment.

This is a hard cross-platform product rule. At minimum, the main window must
expose **Start at Login**, **Run in Background**, icon visibility, a manual
update check, and an explicit way to quit the application. Icon visibility is
an option on every desktop platform: **Show Icon in Menu Bar** on macOS and
**Show Icon in System Tray** on Windows and Linux. Launching the app again from
the Dock, Start menu, application launcher, or equivalent must restore the
existing main window even when that icon is hidden.

Desktop source implements this rule through a main-window app-settings panel
and typed Tauri settings commands. The panel contains every mirrored setting
plus manual update and Quit actions. Icon visibility is persisted and applied
on all three desktop platforms, with migration from the earlier macOS-only
key; menu and tray checkmarks follow the same state.

Production acceptance of this rule is performed from the main window first,
with tray/menu-bar entries tested only as mirrors. The exact clean-install,
update, hidden-icon recovery, process, and production-extension matrix is
defined by the
[desktop production validation runbook](../runbooks/desktop-production-validation.md).

Exact public `v0.1.6` smoke proves the panel and no-tray recovery on macOS and
Linux, but not the rule as a whole. On Windows WebView2 the dialog is confined
to the header strip and is not normally usable. Linux WebKitGTK likewise shows
only the dimmed header rather than the dialog even though AT-SPI initially
reports ideal dialog bounds; focus/interaction can reveal individual rows in
the header strip and scroll the rest outside the viewport. `AppSettings` is
rendered as a `position: fixed` descendant of the shared header, whose
`backdrop-blur` creates a containing block in those engines. The dialog must be
portaled to `document.body` or rendered outside that header. Linux tray
availability also varies by desktop shell and StatusNotifier/AppIndicator
integration, so the main-window route must remain usable with no tray surface.

The same smoke proves that the persisted Run in Background value is not
honored when false. The close handler allows the window to be destroyed but
does not exit the Tauri event loop, leaving a tray-resident process on all
three platforms. Linux can recreate the one existing window when launched
again. Windows can instead leave the first instance without a window, then
accumulate additional invisible launch and `--quit-for-uninstall` processes.
This violates the recoverability rule and requires a release repair.

The exact production extension now exposes a separate Linux process-lifecycle
failure. Native ARM64 Chrome `151.0.7922.71` installed store version `0.1.6`
and cold-launched the exact public AppImage into one visible window and one live
desktop process. While Chrome kept `ok200-host` connected, each repeated launch
focused the existing window but left the exited launch child as a persistent
zombie. The native host must reap spawned children so repeated activation keeps
one live process/window and zero defunct children.

“Shared Rust core” means one native core reused across macOS, Windows, and
Linux, including the ChromeOS Linux controller. Android JNI and a separately
released Rust CLI are not requirements or current directions. The small core
executable remains repository-only development and smoke tooling.

## Current implementation

| Surface | Runtime | Current role | Direction |
|---|---|---|---|
| Desktop source and release `v0.1.6` | Tauri/React control surface; Rust owns persisted server state and `ok200-core` owns native HTTP/filesystem/networking | Complete signed release; exact macOS arm64, Windows NSIS-on-Windows-ARM64-emulation, and Linux arm64 recommended-path smoke passes core serving and integration, but settings-dialog layout, background-close/recovery, and Linux native-host child-reaping defects violate the canonical-main-window and one-process rules | Portal the settings dialog outside the blurred header; make background=false close exit; reap native-host launch children; add no-tray/repeated-extension process regressions; publish a repaired signed release |
| Previous desktop `v0.1.4` | Same Rust-native runtime before the AppImage/Dock/package-awareness repairs | Public updater source used in the accepted `0.1.4` → `0.1.5` macOS, Windows, and Linux transitions | Retain only as immutable update evidence |
| Historical desktop `v0.1.3` | Tauri webview runs `@ok200/engine`; Rust exposes TCP/filesystem commands | Partial legacy release | Historical baseline only |
| Android source | Compose UI; Kotlin owns HTTP, storage adapters, and Android lifecycle policy | Native cutover complete and AVD-validated | Keep broadly compatible through the cross-runtime contract in `android-runtime.md` |
| Android GitHub release `v0.2.1` | Compose UI and native Kotlin implementation | Signed APK/AAB published with the physically accepted ChromeOS LAN-address correction | Exact candidate reportedly submitted to Play; prove the final served build separately |
| Android Play production | May still serve an earlier artifact during review | `v0.2.1` submitted but not yet accepted as store-delivered | Maintainer owns Play review and rollout; prove the final served build separately |
| Retired Node CLI tag `v0.1.1` | Node.js ran the TypeScript engine and Node adapters | npm publication failed; no package or GitHub release was published | Preserve tag/history only; source and release lane removed by Tactical 013 |
| Chrome extension `v0.1.4` candidate | MV3 service worker and popup | Launcher/status surface; exact candidate reportedly submitted to the Chrome Web Store | Desktop launches Tauri through native messaging; ChromeOS exposes best-effort Android launch plus the owned options route; prove store delivery separately |
| Legacy Chrome App `v0.5.x` | Chrome packaged-app APIs | Existing user migration channel | Preserve only long enough to route users to replacements |

The desktop command/state boundary lives in
`desktop/tauri-app/src-tauri/src/server_control.rs`; the Tauri-independent HTTP
implementation lives in `desktop/core`. The old desktop `server.ts`, raw
TCP/filesystem commands, and Tauri TypeScript adapters have been deleted.
Native messaging remains a distinct retained responsibility.

## Rust core boundary

The first core should be deliberately small:

- bind a host and port, including port `0`;
- serve one authorized filesystem root;
- serve files and directory indexes;
- MIME types, `HEAD`, conditional requests, ranges, CORS, and SPA fallback;
- safe URL decoding and canonical containment;
- bounded request/header sizes and timeouts;
- start, stop, restart, and observable status;
- structured request/error events for the UI; and
- deterministic configuration validation.

Prefer `tokio` plus a small, conventional HTTP stack already compatible with
the existing Tauri runtime. Library choice is subordinate to the behavioral
contract and measured footprint; this tactical does not require a custom HTTP
parser or a framework comparison project.

The core must have no Tauri or UI dependency. Tauri owns application lifecycle,
dialogs, tray/autostart/window behavior, settings paths, updater behavior, and
translation between command DTOs and core types.

## Compatibility contract

The migration should preserve, unless a tactical explicitly records a product
change:

- the Tauri bundle identifier `app.ok200.desktop`;
- the updater public key and update endpoint;
- the native messaging host identity and extension launch contract;
- stored settings where their meaning is unchanged;
- the current root, port, CORS, SPA, and background behaviors exposed in the
  desktop UI; and
- the visible start/stop/status workflow.

Upload and HTTPS existed in the retired TypeScript engine but were not exposed
by the desktop UI. They were intentionally retired with that unpublished lane
and require explicit future product decisions; hidden implementation
capability was never a shipped desktop contract.

The Rust core now passes the derived black-box HTTP corpus, but the same
executable harness has not yet been run against both the released TypeScript
server and Rust candidate. Intentional differences need explicit expected
results, not silent test edits, before a release candidate is promoted.

An in-place updater migration is required: a signed current desktop release
must be able to update to the Rust-core release without reinstalling or changing
application identity.

## Non-goals

- Rewriting the React/Tauri management UI.
- Rewriting Android in Rust or pure Kotlin during this campaign.
- Publishing the repository-only Rust core executable as a separate CLI.
- Preserving a generic TypeScript native-I/O abstraction on desktop.
- Adding UDP, UPnP, multiple servers, remote management, or other roadmap
  features before the basic native server and release path are trustworthy.
- Removing the webview; its fixed UI cost is accepted.

## Validation

The Rust cutover is acceptable only when:

1. Core unit/integration tests cover the HTTP and filesystem safety contract.
2. Tauri E2E starts a server through the UI/commands and fetches representative
   files from outside the webview.
3. Start/stop/restart, background/window lifecycle, native messaging launch,
   and persisted configuration are exercised.
4. Resident memory and startup time are measured on the same machine before
   and after the cutover.
5. A signed release candidate passes the artifact gate in
   [`desktop-release-readiness.md`](desktop-release-readiness.md).

## Implemented Rust-native desktop

Tactical 002 fixes the first crate boundary at `desktop/core`, package
`ok200-core`. It uses Tokio plus Axum/Hyper, canonical native filesystem
access, native streaming bodies, a bounded structured-log channel, and
graceful lifecycle state. A development CLI exercises the same public library
without Tauri; Tactical 013 keeps that executable repository-only and
unreleased.

This selection is intentionally reversible at the HTTP-library level: Tauri
will depend on the core's configuration/lifecycle/event API, not Axum types.
The Tauri layer now owns one persisted server configuration, native folder
selection, start-risk assessment, serialized start/stop operations, and
bounded status/request events. The React UI uses narrow Tauri commands and
shows one server with explicit lifecycle state. Empty roots and filesystem
roots are rejected; home, ancestor-of-home, outside-home, and LAN exposure
require confirmation as appropriate.

The desktop TypeScript HTTP server and primitive socket/filesystem IPC have
been removed. The later Tactical 013 cleanup also removed the unpublished Node
CLI, its stranded TypeScript engine, and the CLI-only HTTP management
transport. The desktop app and shared UI retain only the Tauri manager
contract.

The core passes its real-socket HTTP/security corpus and all 28 cases in shared
HTTP contract `1.0.0`; that common run added encoded-separator rejection,
extensionless-only SPA fallback, and `If-Modified-Since` handling where the
independent native runtimes had drifted. The full desktop Rust workspace passes
formatting, strict Clippy, and tests. Its Apple Silicon
release-mode development process measured roughly 2.9 MiB RSS idle and 3.2 MiB
after a request, with a 2.0 MiB unstripped binary. This demonstrates that the
server execution path itself is small; it does not measure the complete Tauri
application or eliminate the webview's fixed UI cost.

The production webview remains a conventional static Vite bundle. Vite's
development server and hot reload are used only by `tauri dev`; the installed
application does not run or require them.

The review app now defaults to the legacy Chrome App's `410x700` portrait
shape, with the canonical logo, wordmark, and yellow accent. Its compact
control surface uses a lifecycle switch with explicit status, point-of-use
explanations for locked settings, a native folder chooser, and distinct
default-browser and Copy actions for the running URL. Window-state storage was
migrated so stale wide-window state does not defeat the new default while
future user resizing remains persistent.

Directory indexes are generated entirely by the Rust core as self-contained
HTML. They show parent, folder, and file icons, human-readable size and
modified metadata, deterministic folder-first ordering, a responsive table,
and automatic browser light/dark presentation. They add no webview or
JavaScript server dependency.

The Tauri webview now also owns a compact in-app updater notification. The
native menu focuses the existing window and requests a manual check; the
webview invokes Tauri's signed updater with `X-Check-Reason: manual` and shows
checking, current, available, progress, installation, and failure state
without opening a separate dialog. It checks quietly five seconds after every
launch with reason `startup`, then every 24 hours while open with reason
`periodic`. Automatic current/error results are quiet unless an update is
available. Available updates provide explicit **Install & Restart** and
**Later** actions. Tauri's embedded bundle identity restricts installation to
macOS app bundles, NSIS, and AppImage; MSI, DEB, and RPM users are directed to
the matching manual download. Signature verification and installation remain
delegated to the Tauri plugin before relaunch through the process plugin.

Window activation uses one create-or-focus path. On macOS, the application
handles Tauri's Dock `Reopen` event by restoring and focusing the configured
main webview, recreating it when the previous window was destroyed. The same
helper backs menu, tray, and single-instance activation. A mock-runtime
regression test exercises creation from the real Tauri window configuration
when no main window exists; packaged Dock activation remains part of macOS
product smoke for the next signed candidate.

## Linux distribution decision

AppImage is the recommended Linux desktop package. The supported installer
places a checksum-verified AppImage at
`~/.local/bin/200-ok.AppImage`, installs browser and desktop integration below
the current user's home directory, and requires no administrator token. A
directly launched AppImage records its real path and installs the same stable
desktop identity, so the copied native host can launch it after the temporary
FUSE mount disappears.

DEB and RPM remain published as secondary system packages for users who
deliberately prefer them. Their installation requires administrator
privileges and their updates are manual until a separate bundle-aware package
update policy is accepted. Linux release artifacts support x86_64 and ARM64;
the exact public ARM64 AppImage now has native Ubuntu ARM64 VM product smoke,
while physical ARM64 hardware remains a separate claim gap.

Implementation and release sequencing are recorded in
[Tactical 008](../tactical/008-appimage-first-linux-distribution.md).

## Known gaps

- Exact public `v0.1.6` packaged UI validation is complete on macOS arm64,
  Windows 11 ARM64 running the x64 NSIS build through Windows emulation, and
  Ubuntu ARM64. The main settings route, icon visibility, autostart, manual
  update, and in-app quit work on macOS. Linux passes the same state changes
  and no-tray relaunch only through AT-SPI/keyboard actions because WebKitGTK
  clips the visual dialog into the header. Windows WebView2 has the same
  immediate visual failure. These are product defects, not remaining smoke
  gaps.
- Disabling Run in Background leaves the process alive after its last window
  closes on macOS, Windows, and Linux. Windows additionally fails the required
  no-tray launch recovery and can accumulate stuck invisible processes. This
  blocks promotion of `v0.1.6` as the hard-rule repair.
- Exact public `v0.1.5` Windows NSIS update and clean-install paths pass
  Authenticode inspection, external start/serve/stop, configuration retention,
  native-host framing, production-extension launch/focus with one process, and
  complete session-1 silent uninstall. Tray-only controls and elevated MSI
  installation remain manual/secondary checks.
- Exact public `v0.1.5` direct and verified-installer AppImages pass signed
  `0.1.4` → `0.1.5` update, stable-path/desktop/native-host retention,
  start/serve/stop, and production-extension launch/focus. The exact DEB
  separately refuses cross-package auto-install and passes the same extension
  identity path. RPM metadata/payload are accepted, but native RPM-family
  install/launch remains untested. Exact `v0.1.6` native Ubuntu ARM64 VM
  AppImage product smoke now passes serving, persistence, updater, autostart,
  tray visibility, in-app quit, and native-host framing/launch. A physical
  Linux ARM64 hardware run and real extension round trip remain claim-only
  gaps. See
  [Tactical 007](../tactical/007-linux-desktop-validation.md),
  [Tactical 008](../tactical/008-appimage-first-linux-distribution.md), and
  [Tactical 009](../tactical/009-release-confidence-closeout.md).
- The WebdriverIO product suite now has one portable Linux runner and a hosted
  `desktop-e2e` job. It installs locked dependencies, owns one `tauri-driver`
  process under Xvfb, exercises UI-driven start/serve/stop plus the settings
  viewport contract, and preserves driver logs and a screenshot on failure.
  This hosted WebKitGTK result does not substitute for installed macOS,
  Windows, or Linux package acceptance.
- The retired TypeScript implementation is no longer available for a shared
  executable harness. Tactical 013 records the behavior disposition; the Rust
  real-socket suite retains the applicable serving and security contract,
  including encoded UTF-8 paths, bodyless missing-file `HEAD`, and HTTP/1.1
  connection reuse.
- Current-vs-candidate whole-app memory, startup, and first-request
  measurements are still missing.
- Signed Rust-core `v0.1.5` is public. Exact prior-public `0.1.4` builds
  installed and relaunched it on macOS app, Windows NSIS, and Linux AppImage
  paths while retaining configuration and product identity. A controlled
  tampered-payload test reached the runtime verifier, which rejected the
  mismatched signature and left the executable unchanged.
- JSTorrent's accepted policy is implemented: a quiet app check five seconds
  after launch, a 24-hour periodic check while open, manual results that are
  always visible, and the native host's independent at-most-daily check.
  MSI/DEB/RPM installations use explicit manual package updates and cannot
  silently cross into NSIS/AppImage ownership.
