mod telemetry;

use std::io::{self, Read, Write};

#[cfg(any(target_os = "linux", target_os = "windows"))]
fn spawn_and_reap(command: &mut std::process::Command, label: String) -> Result<(), String> {
    let mut child = command
        .spawn()
        .map_err(|error| format!("failed to spawn {label}: {error}"))?;
    std::thread::spawn(move || {
        if let Err(error) = child.wait() {
            eprintln!("failed to reap {label}: {error}");
        }
    });
    Ok(())
}

fn read_message_from(reader: &mut impl Read) -> io::Result<Option<serde_json::Value>> {
    let mut len_buf = [0u8; 4];
    match reader.read_exact(&mut len_buf) {
        Ok(()) => {}
        Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => return Ok(None),
        Err(e) => return Err(e),
    }
    let len = u32::from_le_bytes(len_buf) as usize;
    if len > 1024 * 1024 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "message too large",
        ));
    }
    let mut buf = vec![0u8; len];
    reader.read_exact(&mut buf)?;
    let value: serde_json::Value =
        serde_json::from_slice(&buf).map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
    Ok(Some(value))
}

fn read_message() -> io::Result<Option<serde_json::Value>> {
    read_message_from(&mut io::stdin().lock())
}

fn write_message_to(writer: &mut impl Write, value: &serde_json::Value) -> io::Result<()> {
    let json =
        serde_json::to_vec(value).map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
    let len = (json.len() as u32).to_le_bytes();
    writer.write_all(&len)?;
    writer.write_all(&json)?;
    writer.flush()?;
    Ok(())
}

fn write_message(value: &serde_json::Value) -> io::Result<()> {
    write_message_to(&mut io::stdout().lock(), value)
}

#[cfg(target_os = "linux")]
fn linux_app_candidates(host_path: &std::path::Path) -> Vec<std::path::PathBuf> {
    let mut candidates = Vec::new();
    if let Some(dir) = host_path.parent() {
        for name in ["200-ok", "ok200-desktop", "200 OK"] {
            candidates.push(dir.join(name));
        }
    }

    if let Some(appimage) = ok200_common::get_recorded_appimage_path() {
        candidates.push(appimage);
    }

    if let Some(home) = dirs::home_dir() {
        candidates.push(home.join(".local/bin/200-ok.AppImage"));
    }

    candidates
}

fn handle_message(msg: &serde_json::Value) -> serde_json::Value {
    handle_message_with_services(msg, telemetry::maybe_check_for_update, launch_app)
}

fn handle_message_with_services(
    msg: &serde_json::Value,
    telemetry_check: impl FnOnce(),
    launcher: impl FnOnce() -> Result<(), String>,
) -> serde_json::Value {
    let action = msg.get("action").and_then(|v| v.as_str()).unwrap_or("");

    match action {
        "handshake" => {
            telemetry_check();
            serde_json::json!({
                "action": "handshake",
                "version": env!("CARGO_PKG_VERSION"),
                "name": "ok200-host"
            })
        }
        "ping" => {
            serde_json::json!({
                "action": "pong"
            })
        }
        "launch" => match launcher() {
            Ok(()) => serde_json::json!({
                "action": "launch",
                "ok": true
            }),
            Err(e) => serde_json::json!({
                "action": "launch",
                "ok": false,
                "error": e
            }),
        },
        _ => {
            serde_json::json!({
                "error": format!("unknown action: {action}")
            })
        }
    }
}

fn launch_app() -> Result<(), String> {
    #[cfg(target_os = "macos")]
    {
        let status = std::process::Command::new("open")
            .args(["-b", "app.ok200.desktop"])
            .spawn()
            .map_err(|e| format!("failed to run open: {e}"))?
            .wait()
            .map_err(|e| format!("open failed: {e}"))?;
        if !status.success() {
            return Err(format!("open -b exited with {status}"));
        }
        Ok(())
    }

    #[cfg(target_os = "linux")]
    {
        let host_path = std::env::current_exe().map_err(|e| format!("cannot find own exe: {e}"))?;
        for candidate in linux_app_candidates(&host_path) {
            if candidate.is_file() {
                spawn_and_reap(
                    &mut std::process::Command::new(&candidate),
                    candidate.display().to_string(),
                )?;
                return Ok(());
            }
        }

        // Fallback: try gtk-launch with the desktop file
        let status = std::process::Command::new("gtk-launch")
            .arg("200-ok")
            .spawn()
            .map_err(|e| format!("gtk-launch failed: {e}"))?
            .wait()
            .map_err(|e| format!("gtk-launch failed: {e}"))?;
        if status.success() {
            return Ok(());
        }

        Err("could not find 200 OK app".to_string())
    }

    #[cfg(target_os = "windows")]
    {
        let host_path = std::env::current_exe().map_err(|e| format!("cannot find own exe: {e}"))?;
        let dir = host_path
            .parent()
            .ok_or_else(|| "cannot find parent directory".to_string())?;

        for name in ["ok200-desktop.exe", "200 OK.exe"] {
            let app_exe = dir.join(name);
            if app_exe.exists() {
                spawn_and_reap(
                    &mut std::process::Command::new(&app_exe),
                    app_exe.display().to_string(),
                )?;
                return Ok(());
            }
        }

        Err("could not find ok200-desktop.exe beside native host".to_string())
    }

    #[cfg(not(any(target_os = "macos", target_os = "linux", target_os = "windows")))]
    {
        Err("unsupported platform".to_string())
    }
}

fn main() {
    eprintln!("ok200-host: started, pid={}", std::process::id());

    loop {
        match read_message() {
            Ok(Some(msg)) => {
                let response = handle_message(&msg);
                if let Err(e) = write_message(&response) {
                    eprintln!("ok200-host: write error: {e}");
                    break;
                }
            }
            Ok(None) => {
                // stdin closed (extension disconnected)
                break;
            }
            Err(e) => {
                eprintln!("ok200-host: read error: {e}");
                break;
            }
        }
    }

    eprintln!("ok200-host: exiting");
}

#[cfg(test)]
mod tests {
    use super::*;
    #[cfg(target_os = "linux")]
    use serial_test::serial;
    use std::io::Cursor;
    #[cfg(target_os = "linux")]
    use std::os::unix::fs::PermissionsExt;
    #[cfg(target_os = "linux")]
    use std::time::{Duration, Instant};

    #[test]
    fn test_roundtrip_message() {
        let msg = serde_json::json!({"action": "ping"});
        let mut buf = Vec::new();
        write_message_to(&mut buf, &msg).unwrap();

        let mut cursor = Cursor::new(buf);
        let read_back = read_message_from(&mut cursor).unwrap().unwrap();
        assert_eq!(msg, read_back);
    }

    #[test]
    fn test_eof_returns_none() {
        let mut cursor = Cursor::new(Vec::new());
        let result = read_message_from(&mut cursor).unwrap();
        assert!(result.is_none());
    }

    #[test]
    fn test_message_too_large() {
        let len_bytes = (2_000_000u32).to_le_bytes();
        let mut cursor = Cursor::new(len_bytes.to_vec());
        let err = read_message_from(&mut cursor).unwrap_err();
        assert_eq!(err.kind(), io::ErrorKind::InvalidData);
    }

    #[test]
    fn test_handle_handshake() {
        let msg = serde_json::json!({"action": "handshake"});
        let telemetry_called = std::cell::Cell::new(false);
        let response = handle_message_with_services(&msg, || telemetry_called.set(true), || Ok(()));
        assert_eq!(response["action"], "handshake");
        assert_eq!(response["name"], "ok200-host");
        assert!(response["version"].as_str().is_some());
        assert!(telemetry_called.get());
    }

    #[test]
    fn test_handle_ping() {
        let msg = serde_json::json!({"action": "ping"});
        let response = handle_message(&msg);
        assert_eq!(response["action"], "pong");
    }

    #[test]
    fn test_handle_unknown_action() {
        let msg = serde_json::json!({"action": "unknown"});
        let response = handle_message(&msg);
        assert!(response.get("error").is_some());
    }

    #[test]
    fn test_handle_launch_uses_injected_launcher() {
        let msg = serde_json::json!({"action": "launch"});
        let response =
            handle_message_with_services(&msg, || {}, || Err("test launch failure".to_string()));
        assert_eq!(response["action"], "launch");
        assert_eq!(response["ok"], false);
        assert_eq!(response["error"], "test launch failure");
    }

    #[test]
    fn frozen_native_host_messages_cover_old_and_new_extension_pairs() {
        let corpus: serde_json::Value =
            serde_json::from_str(include_str!("../../../tests/compatibility/corpus-v1.json"))
                .expect("compatibility corpus");
        let cases = corpus["nativeHost"]["cases"]
            .as_array()
            .expect("native host fixtures");

        for fixture in cases {
            let request = &fixture["request"];
            let launcher_ok = fixture["launcherResult"].as_str() != Some("error");
            let response = handle_message_with_services(
                request,
                || {},
                || {
                    if launcher_ok {
                        Ok(())
                    } else {
                        Err("fixture launch failure".to_owned())
                    }
                },
            );

            if let Some(expected) = fixture["expected"].as_object() {
                for (key, value) in expected {
                    assert_eq!(
                        &response[key], value,
                        "{} response field {key}",
                        fixture["id"]
                    );
                }
            }
            if let Some(expected_error) = fixture["expectedErrorContains"].as_str() {
                assert!(
                    response["error"]
                        .as_str()
                        .is_some_and(|error| error.contains(expected_error)),
                    "{} expected error containing {expected_error}, got {response}",
                    fixture["id"]
                );
            }
        }
    }

    #[cfg(target_os = "linux")]
    #[test]
    #[serial]
    fn test_linux_candidates_include_recorded_appimage() {
        let tmp = tempfile::tempdir().unwrap();
        let key = "OK200_CONFIG_DIR";
        let original = std::env::var(key).ok();
        std::env::set_var(key, tmp.path().join("config"));

        let appimage = tmp.path().join("custom name.AppImage");
        std::fs::write(&appimage, b"appimage").unwrap();
        let appimage = ok200_common::record_appimage_path(&appimage).unwrap();

        let host = tmp.path().join("lib/ok200/ok200-host");
        let candidates = linux_app_candidates(&host);
        assert!(candidates.contains(&appimage));

        match original {
            Some(val) => std::env::set_var(key, val),
            None => std::env::remove_var(key),
        }
    }

    #[cfg(target_os = "linux")]
    #[test]
    #[serial]
    fn test_repeated_linux_launches_are_reaped_while_host_stays_alive() {
        let tmp = tempfile::tempdir().unwrap();
        let key = "OK200_CONFIG_DIR";
        let original = std::env::var(key).ok();
        std::env::set_var(key, tmp.path().join("config"));

        let pid_file = tmp.path().join("pids");
        let appimage = tmp.path().join("fake.AppImage");
        std::fs::write(
            &appimage,
            format!(
                "#!/bin/sh\nprintf '%s\\n' \"$$\" >> '{}'\nsleep 1\n",
                pid_file.display()
            ),
        )
        .unwrap();
        let mut permissions = std::fs::metadata(&appimage).unwrap().permissions();
        permissions.set_mode(0o755);
        std::fs::set_permissions(&appimage, permissions).unwrap();
        ok200_common::record_appimage_path(&appimage).unwrap();

        let response_started = Instant::now();
        for _ in 0..3 {
            let response = handle_message(&serde_json::json!({"action": "launch"}));
            assert_eq!(response["ok"], true);
        }
        assert!(
            response_started.elapsed() < Duration::from_millis(500),
            "native messaging launch responses waited for child exit"
        );

        let deadline = Instant::now() + Duration::from_secs(10);
        let pids = loop {
            let pids = std::fs::read_to_string(&pid_file)
                .unwrap_or_default()
                .lines()
                .map(str::to_owned)
                .collect::<Vec<_>>();
            if pids.len() == 3 {
                break pids;
            }
            assert!(Instant::now() < deadline, "fake apps did not all launch");
            std::thread::sleep(Duration::from_millis(25));
        };

        for pid in pids {
            let proc_path = std::path::PathBuf::from(format!("/proc/{pid}"));
            while proc_path.exists() && Instant::now() < deadline {
                std::thread::sleep(Duration::from_millis(25));
            }
            assert!(!proc_path.exists(), "launch child {pid} was not reaped");
        }

        match original {
            Some(val) => std::env::set_var(key, val),
            None => std::env::remove_var(key),
        }
    }
}
